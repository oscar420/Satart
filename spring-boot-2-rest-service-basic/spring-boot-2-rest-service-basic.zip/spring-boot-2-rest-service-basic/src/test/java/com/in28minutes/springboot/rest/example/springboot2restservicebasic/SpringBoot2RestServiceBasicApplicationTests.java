package com.in28minutes.springboot.rest.example.springboot2restservicebasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot2RestServiceBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
