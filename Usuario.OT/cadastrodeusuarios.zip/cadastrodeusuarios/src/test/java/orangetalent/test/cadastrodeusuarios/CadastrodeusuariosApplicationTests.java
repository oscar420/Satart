package orangetalent.test.cadastrodeusuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastrodeusuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
