package orangetalent.test.cadastrodeusuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastrodeusuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastrodeusuariosApplication.class, args);
	}

}
